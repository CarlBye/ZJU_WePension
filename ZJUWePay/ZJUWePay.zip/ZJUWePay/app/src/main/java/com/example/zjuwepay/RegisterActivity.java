package com.example.zjuwepay;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Headers;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class RegisterActivity extends AppCompatActivity implements Constant {

    //connection
    private static final String URL_ROOT = "http://47.100.98.181:32006";
    private static final String USER_REGISTER = "/user/register";

    private EditText etRegName, etRegPwd1, etRegPwd2, etRegPhone, etPwdEmail;
    private Button btnRegConfirm;
    private Gson myPack = new Gson();

    private void sendSomething(Map<Object, Object> map) {
        String params = myPack.toJson(map);
        MediaType mediaType = MediaType.parse("application/json; charset=utf-8");
        final RequestBody requestBody = RequestBody.create(mediaType, params);

        Request request = new Request.Builder()
                .url(URL_ROOT + USER_REGISTER)
                .post(requestBody)
                .build();
        OkHttpClient okHttpClient = new OkHttpClient();
        okHttpClient.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                Log.d(TAG, "onFailure: " + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                Log.d(TAG, response.protocol() + " " +response.code() + " " + response.message());
                Headers headers = response.headers();
                for (int i = 0; i < headers.size(); i++) {
                    Log.d(TAG, headers.name(i) + ":" + headers.value(i));
                }
                Map responseInfo;
                responseInfo = myPack.fromJson(response.body().toString(), Map.class);

                Toast errMsg = Toast.makeText(RegisterActivity.this, (String)responseInfo.get("ErrorInfo"), Toast.LENGTH_LONG);
                errMsg.setGravity(Gravity.BOTTOM, 0, 0);
                errMsg.show();

                if((boolean)responseInfo.get("IsSuccess") == true) {
                    //TODO
                }
                Log.d(TAG, "onResponse: " + response.body().string());
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etPwdEmail = findViewById(R.id.et_regEmail);
        etRegName = findViewById(R.id.et_regName);
        etRegPhone = findViewById(R.id.et_regPhone);
        etRegPwd1 = findViewById(R.id.et_regPwd_1);
        etRegPwd2 = findViewById(R.id.et_regPwd_2);

        btnRegConfirm = findViewById(R.id.btn_regConfirm);

        btnRegConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String regName = etRegName.getText().toString();
                String regPwd1 = etRegPwd1.getText().toString();
                String regPwd2 = etRegPwd2.getText().toString();
                String regPhone = etRegPhone.getText().toString();
                String regEmail = etPwdEmail.getText().toString();

                if(!regPwd1.equals(regPwd2)) {
                    Toast errorMsg = Toast.makeText(RegisterActivity.this, "两次密码不一致", Toast.LENGTH_LONG);
                    errorMsg.setGravity(Gravity.BOTTOM, 0, 0);
                    errorMsg.show();
                } else {
                    Map something = new HashMap();
                    something.put("regName", regName);
                    something.put("regPwd", regPwd1);
                    something.put("regPhone", regPhone);
                    something.put("regEmail", regEmail);
                    sendSomething(something);
                    Toast Msg = Toast.makeText(RegisterActivity.this, "发送成功", Toast.LENGTH_LONG);
                    Msg.setGravity(Gravity.BOTTOM, 0, 0);
                    Msg.show();
                }

                Intent intent = new Intent(RegisterActivity.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
