package com.example.zjuwepay;

import androidx.appcompat.app.AppCompatActivity;
import com.example.zjuwepay.ActionHandlers.SlideMenu;
import com.example.zjuwepay.Components.RoundImageView;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements Constant {

    //components
    private ImageView ivOpen, ivBack;
    private SlideMenu slideMenu;
    private RoundImageView btnUserFace;
    private TextView tvUserName;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        slideMenu = findViewById(R.id.slideMenu);

        ivBack = findViewById(R.id.btn_back);
        ivBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                slideMenu.switchMenu();
            }
        });

        ivOpen = findViewById(R.id.btn_menu);
        ivOpen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                slideMenu.switchMenu();
            }
        });

        btnUserFace = findViewById(R.id.user_face);
        btnUserFace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, UserInfoActivity.class);
                startActivity(intent);
            }
        });


        tvUserName = findViewById(R.id.tv_userName);
        tvUserName.setText(PublicData.getCurrentUserName());
    }
}
