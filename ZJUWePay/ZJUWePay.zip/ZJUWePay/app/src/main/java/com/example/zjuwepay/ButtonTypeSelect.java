package com.example.zjuwepay;

public class ButtonTypeSelect {
}
