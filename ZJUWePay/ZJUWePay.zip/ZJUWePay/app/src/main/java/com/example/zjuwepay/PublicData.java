package com.example.zjuwepay;

public class PublicData {

    private static String current_user_name;
    private static boolean log_state = false;

    public static String getCurrentUserName() {
        if(current_user_name == null) {
            return "未登录";
        } else {
            return current_user_name;
        }
    }

    public static void setCurrentUserName(String name) {
        current_user_name = name;
    }

    public static boolean getLogState() {
        return log_state;
    }

    public static void setLogState(boolean state) {
        log_state = state;
    }

}
