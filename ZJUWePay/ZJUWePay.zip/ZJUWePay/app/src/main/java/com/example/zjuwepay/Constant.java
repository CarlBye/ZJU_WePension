package com.example.zjuwepay;

public interface Constant {
    String TAG = "FragmentActivity";
}
